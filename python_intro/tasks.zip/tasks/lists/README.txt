
TASK
-----------

Fill in the code for the functions in the file `lists.py`. 
`main()` function is already set up to call the functions with a few different inputs,
printing 'OK' when each function is correct.
The starter code for each function includes a `!!!Your code here!!!` which is just a placeholder for your code.



