

def lines_from_dir(filepat, dirname):
    '''
    Return sequence of lines from all files for the given `filepat`
    in directory `dirname`
    '''
    # !!!Your code here!!!


def apache_log(lines):
    '''Parse log and map fields to dictionary key/value pairs'''
    # !!!Your code here!!!


